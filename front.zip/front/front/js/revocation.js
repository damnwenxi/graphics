

//撤销函数
function revocation() {
    objs.pop();//移除最后一个元素
    rePaint();//画布重绘
}