/**
 * @desc 鼠标移动事件
 */

 

// 鼠标移动事件
$('canvas').mousemove(function (e) {
    /**
     * @desc 跟踪鼠标位置
     */

    var px = parseInt(e.clientX-of_left);
    var py = parseInt(e.clientY-of_top);
    $('#position').text(px+','+py);

    /**
     * 
     * 
     */

    if (type != null && e.button == 0) {
        switch (type) {

            // case条件顺序不能改变，改变会出错

            case "polygon":
                break;
            case "curve":

                if (down_flag == true) {
                    var ps = new Point();
                    ps.px = e.clientX - of_left;
                    ps.py = e.clientY - of_top;
                    parray[index] = ps;
                    index++;
                    objs[objs.length-1].vertices.push(ps.px,ps.py);
                    update();
                }
                break;
            case "straightLine":
            case "brokenline":
            case "rightangle":
            case "circle":
            case "Ellipse":
            case "elliparc":
            case "rectangle":
            case "roundedrectangle":
            case "positivearc":
                if (down_flag == true) {
                    var ps = new Point();
                    ps.px = e.clientX - of_left;
                    ps.py = e.clientY - of_top;
                    parray[index] = ps;
                    index++;
                    update();
                }
                break;
        }
    }

    // 选中并移动
    if(option.name == "pitch" && down_flag){
        // 计算移动距离
        var px = e.clientX-of_left;
        var py = e.clientY-of_top;
        var dx = px-downPoint[0];
        var dy = py-downPoint[1];

        // 如果是多边形，将多边形顶点存入当前操作对象，深拷贝
        if(option.obj instanceof Polygon){
            // 起始位置
                option.s_vertices = option.obj.vertices.slice(0);
            
        }
        // 当前操作为选中 
        if(option.name == "pitch" && option.obj){
            // 将多边形数组的值加上移动的距离
            for(var i=0; i<option.obj.vertices.length; i+=2){
                option.obj.vertices[i]+=dx;
                option.obj.vertices[i+1]+=dy;
            }
            rePaint();
            // 将移动后的终点位置深拷贝给e_vertices
            option.e_vertices = option.obj.vertices.slice(0);
            option.obj.vertices = option.s_vertices;
        }
    }
});