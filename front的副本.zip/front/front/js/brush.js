$(document).contextmenu(function (e) {
    e.preventDefault();
});
var ctx = getCTX("canvas");     //获取画布
var type = null;                //按钮类型
var parray = [];                //存放当前绘制对象的所有点
var index = 0;                  //数组下标
var objs = [];                  //画布所有对象的集合
var option = {};

// 画布左上角相对于client的坐标
var of_p = $("#canvas").offset();
var of_left = of_p.left;
var of_top = of_p.top;
console.log(of_left, of_top);

/**
 *  鼠标监听事件，不同对象对不同的鼠标事件有不同的反应
 * */

//鼠标是否按下标识
var down_flag = false;

//鼠标按下时的事件
$('canvas').mousedown(function (e) {
    /** 
     * event.button 属性判断鼠标按键类型 
     * 0:左键
     * 1:中键
     * 2:右键
    */

    // 鼠标左键按下走这里
    if (type != null && e.button == 0) {
        var last = objs[objs.length - 1];
        switch (type) {

            case "polygon":
                // 判断上一个多边形是否绘制结束
                if (last.doneFlag) {
                    var obj = createNewItem();
                    objs.push(obj);
                }
                var ps = new Point();
                ps.px = e.clientX - of_left;
                console.log(ps);
                ps.py = e.clientY - of_top;
                if (objs[objs.length - 1].vertices.length < 3) {
                    objs[objs.length - 1].vertices.push(e.clientX - of_left, e.clientY - of_top);
                }
                objs[objs.length - 1].vertices.push(e.clientX - of_left, e.clientY - of_top);
                // console.log(objs[objs.length - 1].vertices);
                parray[index] = ps;
                index++;
                update();
                break;
            case "curve":
                if(last.doneFlag){
                    var obj = createNewItem();
                    objs.push(obj);
                }
                //与建立多边形有点类似需要记录多个点
                down_flag = true;
                var ps = new Point();
                ps.px = e.clientX - of_left;
                ps.py = e.clientY - of_top;
//                更新当前对象的顶点集合
                parray[index] = ps;
                index++;
                objs[objs.length-1].vertices.push(ps.px,ps.py);
//                更新对象里的参数
                update();
                break;
            case "straightLine":
            case "brokenline":
            case "rightangle":
            case "circle":
            case "Ellipse":
            case "elliparc":

            case "rectangle":
            case "roundedrectangle":
            case "positivearc":
                console.log(e.clientX - of_left);
                console.log(e.clientY - of_top);
                obj = createNewItem();//
                obj.level = objs.length;//图元层次为当前图元数组中的下标层次。
                down_flag = true;
                var ps = new Point();
                ps.px = e.clientX - of_left;
                ps.py = e.clientY - of_top;
                objs.push(obj);//放入objs
                //if(parray_ini.length==0){
                //	parray_ini[0]=ps;
                //}
                parray[index] = ps;
                index++;
                update();
                break;
        }
    }
    // 鼠标右键按下走这里
    if (type != null && e.button == 2) {
        switch (type) {
            // 多边形，鼠标右键按下结束
            case "polygon":
                var ex = objs[objs.length - 1].vertices[0];
                var ey = objs[objs.length - 1].vertices[1];
                objs[objs.length - 1].vertices.push(ex, ey);

                // var ps = new Point();
                // ps.px = e.clientX;
                // ps.py = e.clientY - 130;
                // //parray_init[0] = parray_ini[0];
                // parray[index] = ps;
                // index++;
                update();
                objs[objs.length - 1].doneFlag = true;
                parray = [];//数组清空
                index = 0;//下标清空
                // parray = [];//数组清空
                // //parray_ini = [];//数组清空
                // //parray_init = [];//数组清空
                // index = 0;//下标清空
                break;
            case "curve"://曲线
                update();
                objs[objs.length-1].doneFlag = true;
                down_flag = false;
                parray = [];//数组清空
                index = 0;//下标清空
                break;
            case "brokenline":
                break;
        }
    }
    //未选中绘制类型，按左键走这里
    if (type == null && e.button == 0){
        //进行图形选中判断
        //满足选中条件的图形
        var selectobj = [];
        //获取当前鼠标的坐标
        var sx = e.clientX - of_left;;
        var sy = e.clientY - of_top;
        //遍历同一图层所有已绘制图形对象
        i = 0;
        while(i<objs.length){
            var typeOfObj = objs[i].__proto__.constructor.name;
            switch(typeOfObj){
                case "Polygon":
                    if(Polygonpitch(sx,sy,objs[i])!=null){
                        selectobj.push(Polygonpitch(sx,sy,objs[i]));
                    }
                    break;
                case "Line":
                    if(StraightLinepitch(sx,sy,objs[i])!=null){
                        selectobj.push(StraightLinepitch(sx,sy,objs[i]));
                    }
                    break;
                case "Brokenline":
                    if(Brokenlinepitch(sx,sy,objs[i])!=null){
                        selectobj.push(Brokenlinepitch(sx,sy,objs[i]));
                    }
                    break;
                case "Rightangle":
                    if(Rightanglepitch(sx,sy,objs[i])!=null){
                        selectobj.push(Rightanglepitch(sx,sy,objs[i]));
                    }
                    break;
                case "Circle":
                    if(Circlepitch(sx,sy,objs[i])!=null){
                        selectobj.push(Circlepitch(sx,sy,objs[i]));
                    }
                    break;
                case "Curve":
                    if(Curvepitch(sx,sy,objs[i])!=null){
                        selectobj.push(Curvepitch(sx,sy,objs[i]));
                    }
                    break;
                case "Ellipse":
                    if(Ellipsepitch(sx,sy,objs[i])!=null){
                        selectobj.push(Ellipsepitch(sx,sy,objs[i]));
                    }
                    break;
                case "Elliparc":
                    if(Elliparcpitch(sx,sy,objs[i])!=null){
                        selectobj.push(Elliparcpitch(sx,sy,objs[i]));
                    }
                    break;
                case "Rectangle":
                    if(Rectanglepitch(sx,sy,objs[i])!=null){
                        selectobj.push(Rectanglepitch(sx,sy,objs[i]));
                    }
                    break;
                case "Roundedrectangle":
                    if(Roundedrectanglepitch(sx,sy,objs[i])!=null){
                        selectobj.push(Roundedrectanglepitch(sx,sy,objs[i]));
                    }
                    break
                case "Positivearc":
                    if(Positivearcpitch(sx,sy,objs[i])!=null){
                        selectobj.push(Positivearcpitch(sx,sy,objs[i]));
                    }
                    break;
            }
            i++;
        }
        //比较获取对象的图层
        var maxlevel = 0;
        var maxobj = null;
        if(selectobj.length != 0){
            for(var i=0;i<selectobj.length;i++){
                //遭到最大图层
                if(maxlevel<=selectobj[i].level){
                    maxlevel = selectobj[i].level;
                    maxobj = selectobj[i];
                }
            }
        }
        console.log(maxobj);
    }

});

//鼠标抬起事件
$('canvas').mouseup(function (e) {
    if (type != null && e.button == 0) {
        switch (type) {
            case "polygon":
                down_flag = false;
                var ps = new Point();
                ps.px = e.clientX - of_left;
                ps.py = e.clientY - of_top;
                // parray[index] = ps;
                // index++;
                // update();
                // parray = [];//数组清空
                // index = 0;//下标清空

                // obj = createNewItem();//
                // obj.level = objs.length;//图元层次为当前图元数组中的下标层次。
                // objs.push(obj);//放入objs
                // down_flag = true;
                // var ps = new Point();
                // ps.px = e.clientX;
                // ps.py = e.clientY - 130;
                // parray[index] = ps;
                // index++;
                // update();
                break;
            case "rectangle":
                down_flag = false;

                // 裁剪按钮点击之后
                if (option.name == 'clip') {
                    // 最后一个元素是裁剪用的矩形，记录矩形的两个关键点
                    var lastItem = objs[objs.length - 1];
                    option.rx = lastItem.spoint;
                    option.ry = lastItem.epoint;
                    objs.pop();
                }


                // 矩形刷新
                var ps = new Point();
                ps.px = e.clientX - of_left;
                ps.py = e.clientY - of_top;
                parray[index] = ps;
                index++;
                update();
                parray = [];//数组清空
                index = 0;//下标清空
                // console.log("done");

                var lastItem = objs[objs.length - 1];
                // console.log(lastItem instanceof Line);
                 // 判断待裁剪的对象
                if (lastItem instanceof Line) {
                    // 直线走这里
                    var clipType = window.confirm("内裁剪OR外裁剪？");
                    if (clipType) {
                        canvasClear();//画布清空
                        for (var i = 0; i < option.line.length; i += 2) {
                            Inner_cohenSutherland(option.line[i], option.line[i + 1], option.rx, option.ry);
                        }
                        // console.log(objs);

                    } else {
                        canvasClear();//画布清空
                        for (var i = 0; i < option.line.length; i += 2) {
                            Outer_cohenSutherland(option.line[i], option.line[i + 1], option.rx, option.ry);
                        }
                        // console.log(objs);
                    }
                    // 多边形走这里
                }else if(lastItem instanceof Polygon){
                    var vertice = lastItem.vertices;
                    // console.log(vertice);
                    // 预处理多边形顶点数组，去头去尾，设计多边形时根据需要开头顶点push了两次
                    vertice.shift();
                    vertice.shift();
                    vertice.pop();
                    vertice.pop();

                    // 多边形裁剪参数：顶点列表
                    var list = [];
                    for(var i=0;i<vertice.length;i+=2){
                        var ps = new Point;
                        ps.px = vertice[i];
                        ps.py = vertice[i+1];
                        list.push(ps);
                    }
                    // console.log(list);
                    var clipType = window.confirm("内裁剪OR外裁剪？");
                    if (clipType) {
                        objs.pop();
                        rePaint();
                        Mul_Inner_SutherlandHodgman(list,option.rx,option.ry);
                        // console.log(objs);

                    } else {
                        console.log("外裁剪");
                        objs.pop();
                        rePaint();
                        Mul_Outer_WeilerAtherton(list,option.rx,option.ry);
                    }
                }
                break;
            case "brokenline":
            case "straightLine":
            case "rightangle":
            case "circle":
            case "Ellipse":
            case "elliparc":
            case "roundedrectangle":
            case "positivearc":
                down_flag = false;
                var ps = new Point();
                ps.px = e.clientX - of_left;
                ps.py = e.clientY - of_top;
                parray[index] = ps;
                index++;
                update();
                parray = [];//数组清空
                index = 0;//下标清空
                break;
        }
    }

});

// 鼠标移动事件
$('canvas').mousemove(function (e) {
    if (type != null && e.button == 0) {
        switch (type) {

            // case条件顺序不能改变，改变会出错

            case "polygon":
                // var lenOfVertices = objs[objs.length-1].vertices.length;
                // var ps = new Point();
                // ps.px = e.clientX;
                // ps.py = e.clientY - 130;
                // parray[index] = ps;
                // index++;
                // update();
                // objs[objs.length-1].vertices[lenOfVertices-1] = ps;
                break;
            case "curve":

                if (down_flag == true) {
                    var ps = new Point();
                    ps.px = e.clientX - of_left;
                    ps.py = e.clientY - of_top;
                    parray[index] = ps;
                    index++;
                    objs[objs.length-1].vertices.push(ps.px,ps.py);
                    update();
                }
                break;
            case "straightLine":
            case "brokenline":
            case "rightangle":
            case "circle":
            case "Ellipse":
            case "elliparc":
            case "rectangle":
            case "roundedrectangle":
            case "positivearc":
                if (down_flag == true) {
                    var ps = new Point();
                    ps.px = e.clientX - of_left;
                    ps.py = e.clientY - of_top;
                    parray[index] = ps;
                    index++;
                    update();
                }
                break;
        }
    }
});


/*
元素属性更新
 */
function update() {
    // console.log(type);
    //每次更新采用对当前图元对象的属性更新
    switch (type) {
        case "straightLine"://更新直线
            // console.log(objs.length);
            objs[objs.length - 1].spoint = parray[0];
            objs[objs.length - 1].epoint = parray[parray.length - 1];
            break;
        case "brokenline"://更新折线
            // console.log(objs.length);
            objs[objs.length - 1].spoint = parray[0];
            objs[objs.length - 1].epoint = parray[parray.length - 1];
            break;
        case "polygon":/*多边形*/
            // console.log(objs.length);
            //if(parray_init.length!=0){
            //	objs[objs.length-1].init = parray_init[0];}
            // 更新多边形最后一条边 具体未实现
            objs[objs.length - 1].spoint = parray[0];
            objs[objs.length - 1].epoint = parray[parray.length - 1];
            break;
        case "rightangle"://更新直角
            objs[objs.length - 1].spoint = parray[0];
            objs[objs.length - 1].epoint = parray[parray.length - 1];
            break;
        case "circle"://更新圆
            // console.log(objs.length);
            objs[objs.length - 1].center = parray[0];
            objs[objs.length - 1].radius = odistance(parray[0], parray[parray.length - 1]);
            break;
        case "Ellipse"://更新椭圆
            // console.log(objs.length);
            objs[objs.length - 1].center = parray[0];
            objs[objs.length - 1].epoint = parray[parray.length - 1];
            break;
        case "elliparc"://更新椭圆弧
            // console.log(objs.length);
            objs[objs.length - 1].center = parray[0];
            objs[objs.length - 1].epoint = parray[parray.length - 1];
            break;
        case "curve"://更新曲线
            //更新点集合
//         objs[objs.length - 1].plist = objs[objs.length - 1].vertices;
            var keyList = objs[objs.length - 1].vertices;
//		   objs[objs.length - 1].vertices = [];
//		   for(var i=0;i<parray.length;i++){
//		   		objs[objs.length - 1].vertices.push(parray[i].px,parray[i].py);
//		   }
//		   console.log(objs[objs.length - 1].vertices);
//		   objs[objs.length - 1].hlist = objs[objs.length - 1].vertices;
            //分组放入
            objs[objs.length - 1].plist=[];
            for(var i=0; i<keyList.length; i+=20){
                objs[objs.length - 1].plist.push(keyList.slice(i,i+22));
            }
//		   objs[objs.length - 1].plist=[];
//         for(var i=0; i<keyList.length; i++){
//         		objs[objs.length - 1].plist.push(keyList[i]);
//         }
            break;
        case "rectangle"://更新矩形
            // console.log(objs.length);
            objs[objs.length - 1].spoint = parray[0];
            objs[objs.length - 1].epoint = parray[parray.length - 1];
            break;
        case "roundedrectangle"://更新圆角矩形
            // console.log(objs.length);
            objs[objs.length - 1].spoint = parray[0];
            objs[objs.length - 1].epoint = parray[parray.length - 1];
            break;
        case "positivearc"://更新正圆弧
            // console.log(objs.length);
            objs[objs.length - 1].center = parray[0];
            objs[objs.length - 1].radius = odistance(parray[0], parray[parray.length - 1]);
            break;
    }
    //更新之后画布重绘
    rePaint();
}

/*
画布重绘
 */
function rePaint() {
    canvasClear();//画布清空

    // 鼠标松开时才打印，绘图中不打印，打印画布最后一个对象，方便调试
    if (!down_flag) {
        console.log(objs);
    }

    for (var i = 0; i < objs.length; i++) {
        objs[i].draw();
    }
}


//画笔选择
// var isSelect_flag = false;//是否已经选择标识;
//每一次按钮选择新建一个对象元素
function brush(item) {
    console.log(item);
    var items = document.getElementById(item);//查找元素
    //如果是当前一选中类型，颜色变浅，取消选中
    if (item == type) {
        items.style.backgroundColor = '#fff';
        type = null;
    } else {
        if (type != null) {//已有选中但换选别的类型
            var temp = document.getElementById(type);
            temp.style.backgroundColor = '#fff'//原本类型的颜色变浅
        }
        items.style.backgroundColor = '#ddd'//颜色加深

        // 选择不同画笔，全局变量type类型进行改变
        switch (item) {
            case "straightLine":
                type = "straightLine";
                break;
            case "brokenline":
                type = "brokenline";
                break;
            case "rightangle":/*直角*/
                type = "rightangle";
                break;
            case "polygon":/*多边形*/
                type = "polygon";
                var obj = createNewItem();//
                objs.push(obj);
                break;
            case "circle":
                type = "circle";
                break;
            case "Ellipse":
                type = "Ellipse";
                break;
            case "elliparc"://更新椭圆弧	
                type = "elliparc";
                break;
            case "arc":/*圆弧*/
                type = "arc";
                break;
            case "elliparc":/*椭圆弧*/
                type = "elliparc";
                break;
            case "curve"://更新曲线
                type = "curve";
                //这里建了一个对象
                var obj = createNewItem();
                objs.push(obj);
                break;
            case "roundedrectangle":/*圆角矩形*/
                type = "roundedrectangle";
                break;
            case "rectangle":
                type = "rectangle";
                break;
            case "positivearc":/*正圆弧*/
                type = "positivearc";
                break;
        }
    }
}


/*
获取画布
 */
function getCTX(id) {
    var canvas_dom = document.getElementById(id);
    var ctx = canvas_dom.getContext("2d");
    return ctx;
}

/*
画布清空
 */
function canvasClear() {
    var c = document.getElementById("canvas");
    ctx.clearRect(0, 0, c.width, c.height);
}


/*
新建对象
 */
function createNewItem() {
    //根据全部变量type进行对象的新建
    switch (type) {
        case "straightLine":
            return new Line();
            break;
        case "brokenline":
            return new Brokenline();
            break;
        case "circle":
            return new Circle();
            break;
        case "Ellipse":
            return new Ellipse();
            break;
        case "elliparc":
            return new Elliparc();
            break;
        case "rightangle":
            return new Rightangle();
            break;
        case "polygon":
            return new Polygon();
            break;
        case "arc":
            return new Arc();
            break;
        case "elliparc":
            return new Elliparc();
            break;
        case "curve":
            return new Curve();
            break;
        case "roundedrectangle":
            return new Roundedrectangle();
            break;
        case "rectangle":
            return new Rectangle();
            break;
        case "positivearc":
            return new Positivearc();
            break;

    }
}

/*
父类（所有画布上的元素对象）
所有图元对象都继承该对象
 */
function Drawable() {
    this.level = 0;         //元素层次，用于后续，带不同颜色的图元的刷新
    this.id = 0;            //元素id
    this.color = "#000000"; //元素颜色，默认颜色黑色
    this.weight = 1;        //元素宽度，默认图元线条宽度
    this.vertices = [];     // 数组对象，存放图形顶点
    this.edgepoints = new Array();
}

/*
点对象
 */
function Point(px, py, type) {
    //继承父类
    Drawable.apply(this);

    // arguments 属性获取当前方法的参数
    this.px = arguments[0] ? arguments[0] : 0;
    this.py = arguments[1] ? arguments[1] : 0;
    this.type = arguments[2] ? arguments[2] : null;
    /*
    点亮一个点
     */
    this.draw = function () {
        //绘制成矩形
        ctx.fillRect(this.px, this.py, 1, 1);
    }
}

/*
直线对象
 */
function Line() {
    Drawable.apply(this);//继承父类
    this.spoint = new Point();//起始点
    this.epoint = new Point();//终止点
    this.draw = function () {
        var pax = this.spoint.px;
        var pay = this.spoint.py;
        var pbx = this.epoint.px;
        var pby = this.epoint.py;
        var dx = pbx - pax;
        var dy = pby - pay;
        var x = pax;
        var y = pay;
        var eps;
        if (Math.abs(dx) > Math.abs(dy)) {
            eps = Math.abs(dx);
        } else {
            eps = Math.abs(dy);
        }
        var xlincre = dx * 1.0 / eps;
        var ylincre = dy * 1.0 / eps;
        for (var i = 0; i <= eps; i++) {
            var tp = new Point(parseInt(x + 0.5), parseInt(y + 0.5));
            tp.draw();//画点
            // if (down_flag == false) {
            //     this.edgepoints.push(tp);
            // }
            x += xlincre;
            y += ylincre;

        }
    }
}

/*
折线对象
*/
function Brokenline() {
    Drawable.apply(this);//继承父类
    this.spoint = new Point();//起始点
    this.epoint = new Point();//终止点
    this.draw = function () {
        var pax = this.spoint.px;
        var pay = this.spoint.py;
        var pbx = this.epoint.px;
        var pby = this.epoint.py;
        var dx = pbx - pax;
        var dy = pby - pay;
        var x = pax;
        var y = pay;
        var eps;
        if (Math.abs(dx) > Math.abs(dy)) {
            eps = Math.abs(dx);
        } else {
            eps = Math.abs(dy);
        }
        var xlincre = dx * 1.0 / eps;
        var ylincre = dy * 1.0 / eps;
        for (var i = 0; i <= eps; i++) {
            new Point(x, y).draw();//画点

            x += xlincre;
            y += ylincre;

        }
    }
}

/*
多边形对象
*/
function Polygon() {
    Drawable.apply(this);       //继承父类
    this.edges = new Array();
    this.doneFlag = false;

    this.draw = function () {
        for (var j = 0; j < this.vertices.length; j += 2) {
            var pax = this.vertices[j];
            var pay = this.vertices[j + 1];
            var pbx = this.vertices[j + 2];
            var pby = this.vertices[j + 3];
            var dx = pbx - pax;
            var dy = pby - pay;
            var x = pax;
            var y = pay;
            var eps;

            if (Math.abs(dx) > Math.abs(dy)) {
                eps = Math.abs(dx);
            } else {
                eps = Math.abs(dy);
            }
            var xlincre = dx * 1.0 / eps;
            var ylincre = dy * 1.0 / eps;
            for (var i = 0; i <= eps; i++) {
                var tp = new Point(parseInt(x + 0.5), parseInt(y + 0.5));
                tp.draw();//画点
                // if (down_flag == false) {
                //     this.edgepoints.push(tp);
                // }
                x += xlincre;
                y += ylincre;
            }
        };
    }
}

/*曲线*/
function Curve(){
    //基于贝尔塞曲线画法
    //初步实现:根据点来绘制
    Drawable.apply(this);//继承父类
    this.plist = [];//顶点分部集合
    this.doneFlag = false; //结束标志
    //需要限定更新范围10个点为一段
    this.draw = function () {
        var t = this.plist;
        for(var i = 0;i<t.length;i++){
            Curvelist(t[i],t[i].length-1);
        }
//		Curvelist(t,t.length-1);
//	 	var stest = [];
//	 	for(var j = 0;j<this.plist.length;j++){
//	 		stest.push(parseInt(this.plist[j][0]),parseInt(this.plist[j][1]));
//	 	}
//	 	Curvelist(stest,stest.length-1);
//	 	for(var j = 0;j<this.plist.length;j++){
//	 		Curvelist(this.plist[j],this.plist[j].length-1);
//	 	}
//		console.log(this.vertices);
//		Curvelist(this.hlist,this.hlist.length-1);
//		Curvelist(i,j);
    }
}

//n为数组长度-1
//p为2倍点数
function Curvelist(pp,n)
{
    var p = [];
    for(var i = 0;i<=pp.length-1;i++){
        p.push(pp[i]);
    }
    if (n<= 1)
        return null;
    if((p[n-1]<p[0]+1)&&(p[n-1]>p[0]-1)&&(p[n]<p[1]+1)&&(p[n]>p[1]-1))
    {
//		new Point(parseInt(p[0]), parseInt(p[1])).draw();
        ctx.fillRect(parseInt(p[0]), parseInt(p[1]), 1, 1);
        return null;
    }
    p1 = [];
    var i, j;
    p1.push(p[0],p[1]);
    for(i=2; i<=n; i+=2)
    {
        for(j=0; j<=n-i;j+=2)
        {
            p[j] = (p[j] + p[j+2])/2;
            p[j+1] = (p[j+1] + p[j+3])/2;
        }
        p1.push(p[0],p[1]);
    }
    Curvelist(p1,p1.length-1);
    Curvelist(p,p.length-1);
}

/*直角*/
function Rightangle() {
    Drawable.apply(this);//继承父类
    this.spoint = new Point();//起始点
    this.epoint = new Point();//终止点
    this.draw = function () {
        var pax = this.spoint.px;
        var pay = this.spoint.py;
        var pbx = this.epoint.px;
        var pby = this.epoint.py;
        var dx = pbx - pax;
        var dy = pby - pay;
        var x = pax;
        var y = pay;
        var eps;
        if (Math.abs(dx) > Math.abs(dy)) {
            eps = Math.abs(dx);
        } else {
            eps = Math.abs(dy);
        }
        var xlincre = dx * 1.0 / eps;
        var ylincre = dy * 1.0 / eps;
        for (var i = 0; i <= eps; i++) {
            new Point(pax, y).draw();//画点
            new Point(x, pby).draw();//画点
            x += xlincre;
            y += ylincre;
        }
    }
}

/*圆角矩形*/
function Roundedrectangle() {
    Drawable.apply(this);//继承父类
    this.spoint = new Point();//起始点
    this.epoint = new Point();//终止点
    this.draw = function () {
        var pax = this.spoint.px;
        var pay = this.spoint.py;
        var pbx = this.epoint.px;
        var pby = this.epoint.py;
        var dx = pbx - pax;
        var dy = pby - pay;
        var x = pax;
        var y = pay;
        var eps;
        if (Math.abs(dx) > Math.abs(dy)) {
            eps = Math.abs(dx);
        } else {
            eps = Math.abs(dy);
        }
        var xlincre = dx * 1.0 / eps;
        var ylincre = dy * 1.0 / eps;
        var kx = 10 * (Math.abs(pbx - pax)) / (pbx - pax);
        var ky = 10 * (Math.abs(pby - pay)) / (pby - pay);
        pax -= kx; pbx += kx; pay -= ky; pby += ky;
        Rounde(pax, pay, pbx, pby);
        for (var i = 0; i <= eps; i++) {
            new Point(pax, y).draw();//画点
            new Point(x, pby).draw();//画点
            new Point(pbx, y).draw();//画点
            new Point(x, pay).draw();//画点
            x += xlincre;
            y += ylincre;
        }
    }
}

/*矩形*/
function Rectangle() {
    Drawable.apply(this);//继承父类
    this.spoint = new Point();//起始点
    this.epoint = new Point();//终止点
    this.draw = function () {
        var pax = this.spoint.px;
        var pay = this.spoint.py;
        var pbx = this.epoint.px;
        var pby = this.epoint.py;
        var dx = pbx - pax;
        var dy = pby - pay;
        var x = pax;
        var y = pay;
        var eps;
        if (Math.abs(dx) > Math.abs(dy)) {
            eps = Math.abs(dx);
        } else {
            eps = Math.abs(dy);
        }
        var xlincre = dx * 1.0 / eps;
        var ylincre = dy * 1.0 / eps;
        for (var i = 0; i <= eps; i++) {
            new Point(pax, y).draw();//画点
            new Point(x, pby).draw();//画点
            new Point(pbx, y).draw();//画点
            new Point(x, pay).draw();//画点
            x += xlincre;
            y += ylincre;

        }
    }
}

/*正圆弧*/
function Positivearc() {
    this.center = new Point();//圆心
    this.radius = 0;//半径
    this.draw = function () {
        var cx = this.center.px;//圆心x坐标
        var cy = this.center.py;//圆心y坐标
        var da = 1.0 / (this.radius + 1);
        var radin = Math.PI / 4;//1/8弧即1/4pi
        var steps = parseInt(radin / da);
        var x = this.radius * Math.cos(0);
        var y = this.radius * Math.sin(0);
        for (var i = 0; i <= steps; i++) {
            new Point(x + cx, -y + cy).draw();//画点2
            new Point(-x + cx, -y + cy).draw();//画点4
            new Point(y + cx, -x + cy).draw();//画点7
            new Point(-y + cx, -x + cy).draw();//画点8
            x -= y * da;
            y += x * da;
        }
    }
}

/*
椭圆弧
*/
function Elliparc() {
    this.center = new Point();//椭圆心
    this.epoint = new Point();//鼠标点
    this.draw = function () {
        var cx = this.center.px;//椭圆心x坐标
        var cy = this.center.py;//椭圆心y坐标
        var px = this.epoint.px;
        var py = this.epoint.py;

        var X = Math.pow(Math.abs(px - cx), 2);
        var Y = Math.pow(Math.abs(py - cy), 2);


        var B = (Y + Math.sqrt(Math.pow(Y, 2) + 4 * Y * X)) / 2;
        var A = B + X;
        var a = Math.sqrt(A);
        var b = Math.sqrt(B);


        var x = 0;
        var y = b;
        var d1 = b * b + a * a * (-b + 0.25);
        new Point(cx + x, cy + y).draw();//画点1
        while (b * b * (x + 1) < a * a * (y - 0.25)) {
            if (d1 < 0) {
                d1 += b * b * (2 * x + 3);
                x++;
            }
            else {
                d1 += b * b * (2 * x + 3) + a * a * (-2 * y + 2);
                x++;
                y--;
            }
            new Point(x + cx, -y + cy).draw();//画点2
            new Point(-x + cx, -y + cy).draw();//画点4
        }
        var d2 = Math.sqrt(b * (x + 0.5)) + Math.sqrt(a * (y - 1)) - Math.sqrt(b * a);

        while (y > 0) {
            if (d2 < 0) {
                d2 += b * b * (2 * a + 2) + a * a * (-2 * y + 3);
                x++ , y--;
            }
            else {
                d2 += b * b * (2 * a + 2) + a * a * (-2 * y + 3) - b * b * (2 * a + 2);
                y--;
            }
            new Point(x + cx, -y + cy).draw();//画点2
            new Point(-x + cx, -y + cy).draw();//画点4
        }
    }
}

/*
椭圆
*/
function Ellipse() {
    this.center = new Point();//椭圆心
    this.epoint = new Point();//鼠标点
    this.draw = function () {
        var cx = this.center.px;//椭圆心x坐标
        var cy = this.center.py;//椭圆心y坐标
        var px = this.epoint.px;
        var py = this.epoint.py;

        var X = Math.pow(Math.abs(px - cx), 2);
        var Y = Math.pow(Math.abs(py - cy), 2);


        var B = (Y + Math.sqrt(Math.pow(Y, 2) + 4 * Y * X)) / 2;
        var A = B + X;
        var a = Math.sqrt(A);
        var b = Math.sqrt(B);


        var x = 0;
        var y = b;
        var d1 = b * b + a * a * (-b + 0.25);
        new Point(cx + x, cy + y).draw();//画点1
        while (b * b * (x + 1) < a * a * (y - 0.25)) {
            if (d1 < 0) {
                d1 += b * b * (2 * x + 3);
                x++;
            }
            else {
                d1 += b * b * (2 * x + 3) + a * a * (-2 * y + 2);
                x++;
                y--;
            }
            new Point(x + cx, y + cy).draw();//画点1
            new Point(x + cx, -y + cy).draw();//画点2
            new Point(-x + cx, y + cy).draw();//画点3
            new Point(-x + cx, -y + cy).draw();//画点4
        }
        var d2 = Math.sqrt(b * (x + 0.5)) + Math.sqrt(a * (y - 1)) - Math.sqrt(b * a);

        while (y > 0) {
            if (d2 < 0) {
                d2 += b * b * (2 * a + 2) + a * a * (-2 * y + 3);
                x++ , y--;
            }
            else {
                d2 += b * b * (2 * a + 2) + a * a * (-2 * y + 3) - b * b * (2 * a + 2);
                y--;
            }
            new Point(x + cx, y + cy).draw();//画点1
            new Point(x + cx, -y + cy).draw();//画点2
            new Point(-x + cx, y + cy).draw();//画点3
            new Point(-x + cx, -y + cy).draw();//画点4
        }
    }
}

/*
圆对象
 */
function Circle() {
    this.center = new Point();//圆心
    this.radius = 0;//半径
    this.draw = function () {
        var cx = this.center.px;//圆心x坐标
        var cy = this.center.py;//圆心y坐标

        var da = 1.0 / (this.radius + 1);
        var radin = Math.PI / 4;//1/8弧即1/4pi
        var steps = parseInt(radin / da);
        var x = this.radius * Math.cos(0);
        var y = this.radius * Math.sin(0);
        for (var i = 0; i <= steps; i++) {
            new Point(x + cx, y + cy).draw();//画点1
            new Point(x + cx, -y + cy).draw();//画点2
            new Point(-x + cx, y + cy).draw();//画点3
            new Point(-x + cx, -y + cy).draw();//画点4
            new Point(y + cx, x + cy).draw();//画点5
            new Point(-y + cx, x + cy).draw();//画点6
            new Point(y + cx, -x + cy).draw();//画点7
            new Point(-y + cx, -x + cy).draw();//画点8
            x -= y * da;
            y += x * da;
        }
    }
}

/*
求两个点直接的欧式距离
 */
function odistance(p1, p2) {
    var dx = Math.pow(Math.abs(p1.px - p2.px), 2);
    var dy = Math.pow(Math.abs(p1.py - p2.py), 2);
    return Math.sqrt(dx + dy);
}

/*
求椭圆的长短轴
*/
function Ellipse_ab(p1, p2) {
    var X = Math.pow(Math.abs(p1.px - p2.px), 2);
    var Y = Math.pow(Math.abs(p1.py - p2.py), 2);
    //a>b
    var B = (Y + Math.sqrt(Math.pow(Y) + 4 * Y * X)) / 2;
    var A = B + X;
    var a0 = Math.sqrt(A);
    var b0 = Math.sqrt(B);
    return a0, b0;
}

/*圆角*/
function Rounde(ax, ay, bx, by) {
    this.radius = 10;//半径   ----》此处可更改圆角大小
    var cx = (ax + bx) / 2;//圆心x坐标
    var cy = (ay + by) / 2;//圆心y坐标

    var da = 1.0 / (10);
    var radin = Math.PI / 4;//1/8弧即1/4pi
    var steps = parseInt(radin / da);
    var x = this.radius * Math.cos(0);
    var y = this.radius * Math.sin(0);
    var dx = Math.abs(bx - ax) / 2 - 10;
    var dy = Math.abs(by - ay) / 2 - 10;

    cx += dx; cy += dy;
    for (var i = 0; i <= 10; i++) {
        new Point(x + cx, y + cy).draw();//画点1
        new Point(y + cx, x + cy).draw();//画点5
        x -= y * da;
        y += x * da;
    }

    cx = (ax + bx) / 2; cy = (ay + by) / 2;
    x = this.radius * Math.cos(0); y = this.radius * Math.sin(0);
    cx += dx; cy -= dy;
    for (var i = 0; i <= 10; i++) {
        new Point(x + cx, -y + cy).draw();//画点2
        new Point(y + cx, -x + cy).draw();//画点7
        x -= y * da;
        y += x * da;
    }

    cx = (ax + bx) / 2; cy = (ay + by) / 2;
    x = this.radius * Math.cos(0); y = this.radius * Math.sin(0);
    cx -= dx; cy += dy;
    for (var i = 0; i <= 10; i++) {
        new Point(-x + cx, y + cy).draw();//画点3
        new Point(-y + cx, x + cy).draw();//画点6
        x -= y * da;
        y += x * da;
    }

    cx = (ax + bx) / 2; cy = (ay + by) / 2;
    x = this.radius * Math.cos(0); y = this.radius * Math.sin(0);
    cx -= dx; cy -= dy;
    for (var i = 0; i <= 10; i++) {
        new Point(-x + cx, -y + cy).draw();//画点4
        new Point(-y + cx, -x + cy).draw();//画点8
        x -= y * da;
        y += x * da;
    }

}